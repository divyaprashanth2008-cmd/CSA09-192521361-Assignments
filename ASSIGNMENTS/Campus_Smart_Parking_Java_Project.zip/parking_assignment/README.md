# Campus Smart-Parking System – Assignment 1 (CO1)

## Student details
- Name: <Enter your name>
- Register number: <Enter your register number>
- Java version: Java 17 or later
- Repository: `CSA09-<RegisterNumber>-Assignment1`

## Contents
- `Task03/ParkingFacility.java` – completed allocation/release TODO exercise.
- `Task08/FeeDemo.java` – completed Vehicle/Chargeable polymorphism exercise.
- `src/parking/app/ParkingSystem.java` – integrated demonstration including uneven floors, vehicle classes, tickets, pass interfaces, fee calculation, and HashMap-based active ticket storage.
- `../Campus_Smart_Parking_Assignment1_Report.docx` – written report (copy into repository root before pushing).

## Compile and run
Run these commands from the repository root:

```bash
mkdir -p out
javac -d out Task03/ParkingFacility.java Task08/FeeDemo.java src/parking/app/ParkingSystem.java
java -cp out ParkingFacility
java -cp out FeeDemo
java -cp out parking.app.ParkingSystem
```

## Expected demonstration outputs

### Task03
```text
[0, 0]
[0, 1]
[1, 0]
null
true false false
[0, 1]
```

### Task08
```text
TwoWheeler TN01A1 -> Rs 30.0
Car TN02B2 -> Rs 90.0
ElectricCar TN03C3 -> Rs 210.0
true
```

### Integrated demo
```text
TwoWheeler fee: Rs 20.00
EV fee: Rs 90.00
E-bike fee: Rs 20.00
Delivery van fee: Rs 60.00
Active tickets: 0
```

The fee rates in the demonstration are illustrative because the assignment brief does not specify exact monetary rates. Confirm any faculty-prescribed tariff before final submission. Run the programs on your own computer and add your own terminal screenshots under the relevant task folders.

## Submission reminders
1. Add one folder for every task required by the assignment, including code, test inputs and output screenshots.
2. Commit progressively, with at least one meaningful commit for each task.
3. Add the working GitHub URL to the report cover page and submit it through the course portal.
4. Be prepared to explain and modify the code during viva.
